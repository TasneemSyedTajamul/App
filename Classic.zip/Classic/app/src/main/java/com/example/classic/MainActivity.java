package com.example.classic;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Toast;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    MediaPlayer player, p;

    private static int Mic_Permission_Code= 200;

    MediaRecorder mediarecorder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        player= MediaPlayer.create(this, R.raw.level1);
        setContentView(R.layout.activity_main);


        if(isMicrophonePresent())
        {
            getMicrophonePermission();
        }
    }

    public void PlayLesson(View view) {
        player.start();
        Toast.makeText(getApplicationContext(), "Lesson is played", Toast.LENGTH_SHORT).show();
    }

    public void PauseLesson(View view) {
        player.pause();
        Toast.makeText(getApplicationContext(), "Lesson is paused", Toast.LENGTH_SHORT).show();
    }

    public void RecordingStarted(View view) {

        try{
            mediarecorder= new MediaRecorder();
            mediarecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            mediarecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
            mediarecorder.setOutputFile(getRecordingFilePath());
            mediarecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
            mediarecorder.prepare();
            mediarecorder.start();
            Toast.makeText(getApplicationContext(), "Recording started", Toast.LENGTH_SHORT).show();
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

    public void RecordingStoppped(View view) {
        mediarecorder.stop();
        mediarecorder.release();
        mediarecorder= null;
        Toast.makeText(getApplicationContext(), "Recording stopped", Toast.LENGTH_SHORT).show();

    }

    public void RecordingPlayed(View view) {

        try {
            p = new MediaPlayer();
            p.setDataSource(getRecordingFilePath());
            p.prepare();
            p.start();
            Toast.makeText(getApplicationContext(), "Recording played", Toast.LENGTH_SHORT).show();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    public void TestVoice1(View view) {
        Intent intent = new Intent(MainActivity.this,activity2.class);
        startActivity(intent);
    }

    public boolean isMicrophonePresent()
    {
        if(this.getPackageManager().hasSystemFeature(PackageManager.FEATURE_MICROPHONE))
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    private void getMicrophonePermission()
    {
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_DENIED)
        {
            ActivityCompat.requestPermissions(this, new String[]
            { Manifest.permission.RECORD_AUDIO}, Mic_Permission_Code);
        }
    }

    private String getRecordingFilePath()
    {
        ContextWrapper contextWrapper= new ContextWrapper(getApplicationContext());
        File musicDirectory= contextWrapper.getExternalFilesDir(Environment.DIRECTORY_MUSIC);
        File file= new File(musicDirectory,"level1user"+ ".mp3");
        return file.getPath();
    }

}