package com.example.classic;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContextWrapper;
import android.content.Intent;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Toast;

import java.io.File;

public class activity3 extends AppCompatActivity {

    MediaRecorder media;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);
    }

    public void RecordingStarted2(View view) {

        try{
            media= new MediaRecorder();
            media.setAudioSource(MediaRecorder.AudioSource.MIC);
            media.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
            media.setOutputFile(getRecordingFilePath());
            media.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
            media.prepare();
            media.start();
            Toast.makeText(getApplicationContext(), "Recording started", Toast.LENGTH_SHORT).show();
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

    public void RecordingStoppped2(View view) {
        media.stop();
        media.release();
        media= null;
        Toast.makeText(getApplicationContext(), "Recording stopped", Toast.LENGTH_SHORT).show();

    }

    public void TestVoice2(View view) {
        Intent intent= new Intent(activity3.this, Activity4.class);
        startActivity(intent);
    }

    private String getRecordingFilePath()
    {
        ContextWrapper contextWrapper= new ContextWrapper(getApplicationContext());
        File musicDirectory= contextWrapper.getExternalFilesDir(Environment.DIRECTORY_MUSIC);
        File file2= new File(musicDirectory,"level1expert"+ ".mp3");
        return file2.getPath();
    }
}